
package biblioteca;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

// Nos aseguramos que los inventarios génericos implementen la interfaz CSVSerializable para poder guardar y cargar
public class Inventario<T extends CSVSerializable> {
    List<T> inventario = new ArrayList<>();
    
    
    public void agregarItem(T item) {
        checkItem(item);
        inventario.add(item);
    }
    
    private void checkItem(T item) {
        if(item == null){
            throw new NullPointerException("Libro núlo");
        }
        
        if(inventario.contains(item)) {
            throw new RepeatedItemException();
        }
        
    }
    
    public void eliminarItem(int index){
      
        checkIndice(index, "No se puede eliminar el item");
        inventario.remove(index);   
    }
    
 
    private void checkIndice(int index, String msg) {
         if(!(index >= 0 && index < inventario.size())) {
            throw new IndexOutOfBoundsException(msg);
        }
    }
    
    public T obtenerItem(int index) {
        checkIndice(index, "No se puede obtener el item");
        
        return inventario.get(index);
    }
    
    
    public List<T> filtrarItems (Predicate<? super T> criterio) {
        List<T> aux = new ArrayList<>();

        for (T item : inventario) {
            if(criterio.test(item)) {
                aux.add(item);
           }
        }

        return aux;   
    }
    
    public void ordenarItems() {
        ordenarItems((Comparator<? super T>) Comparator.naturalOrder());
    }
    
    public void ordenarItems(Comparator<? super T> criterio) {
        // Verificar si la lista esta vacia o si los elementos son comparables
        if(inventario.isEmpty() || !(inventario.get(0) instanceof Comparable)){
            throw new RuntimeException("Lista vacía u objetos no comparables");
        }
        
       inventario.sort(criterio);
    }
    
    public void guardarEnArchivo(String path) throws IOException{
          try(FileOutputStream archivo = new FileOutputStream(path); 
           ObjectOutputStream salida = new ObjectOutputStream(archivo)){
           
           salida.writeObject(inventario);
           
          }
    }
    
    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException, FileNotFoundException{
       
       try(ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))){             

        inventario = (ArrayList<T>) entrada.readObject();
        System.out.println("Lista de empleados recuperada");
           
       }    
     
    }
    
    public void guardarEnCSV(String path) throws IOException {
       crearArchivo(path);

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))){
            bw.write("dni,nombre,sueldo,sector\n");
            for(T item : inventario) {
                
                bw.write(item.toCSV() + "\n");
            }
        } catch(IOException ex) {
            System.out.println(ex);
        }
    }
    
    private void crearArchivo(String path) throws IOException{
        File archivo = new File(path);
       
        if(!archivo.exists()) {    
            archivo.createNewFile();
        } else {
            System.out.println("Archivo ya existe, reemplazando..");
        }
    }
    
    
    public void cargarDesdeCSV (String path, Function<String, T> constructor) throws IOException, FileNotFoundException{
        
        List<T> cargaInventario = new ArrayList<>();
        
        try (BufferedReader lectorbf = new BufferedReader(new FileReader(path))){ 

            String linea;
            
            lectorbf.readLine();
            
            while((linea = lectorbf.readLine()) != null){
                if(linea.endsWith("\n")) {
                    linea = linea.substring(linea.length() - 1);
                }
                    
                // Transformar String en un objeto tipo T
                T item = constructor.apply(linea);

                cargaInventario.add(item);

                }
            }
        
       inventario = cargaInventario;
    }
    
    public void paraCadaElemento(Consumer<? super T> consumidor) {
        for(T item : inventario) {
            consumidor.accept(item);
        }
    }
    
    
    
}
