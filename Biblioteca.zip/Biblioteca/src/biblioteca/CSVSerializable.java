
package biblioteca;

public interface CSVSerializable<T> {
    
    String toCSV();
   
}
